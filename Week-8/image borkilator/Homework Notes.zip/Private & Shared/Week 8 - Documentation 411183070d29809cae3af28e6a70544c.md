# Week 8 - Documentation

## Links

- **Homework slide:** https://course-production-b83a.up.railway.app/portal/#course/week/8/notes
- **Class contract:** https://course-production-b83a.up.railway.app/portal/#course/document/agents%2Fmodes%2Freviewer.md
- **Homework guide:** https://course-production-b83a.up.railway.app/portal/#course/week/8/notes

## Assignments

- Bring one revision or small experiment: remix a project, make a deliberate variation, or build a tool for yourself.
- Keep a compact process record: intention; what changed and stayed; one before/after check; your decisions, credits and AI contribution; one remaining question.
- Bring one class-contract proposal grounded in something you observed. A private note or card is valid.
    - Link: https://course-production-b83a.up.railway.app/portal/#course/contract

## Background

I struggled a little bit to think of examples of past work for HelloWorld I was interested in iterating on further. Truthfully, for almost all of the projects we’ve been working on, I’m either happy with where they are at or I’m not that excited about what direction I can take them in. This is not to say I have found this work very inspiring or fulfilling – probably the opposite. For several projects I’ve been coming back outside of class time to continue tinkering because I’ve found them really fun or interesting. These include the [murmuration clock](https://github.com/pmartin5-gif/HelloWorld/tree/main/Week-6/Experiments/Experiment-01-Murmuration-Clock) and the [falling ash/falling snow clock](https://github.com/pmartin5-gif/HelloWorld/tree/main/Week-6/Experiments/Experiment-03), and also another version I did which was a [rain clock](https://github.com/pmartin5-gif/HelloWorld/tree/main/Week-6/Experiments/experiment-04). I have some ideas for the future of maybe taking these concepts and projecting them and having them interact with somebody’s body, but that feels too ambitious for this project.

There were, however, a couple of ideas I’ve been working on on the side for other classes.

One idea is to use a workflow I built to create images and project them onto an LED board and making it so that anyone in the studio could do this by email or a slackbot. I’ve been working with Codex to help me do this and apparently this is actually really complicated. I’ve been keeping track of documentation and also used codex to create (and execute much of) a product plan.

- [Link - github folder](https://github.com/pmartin5-gif/HelloWorld/tree/main/Week-8/LightBoard_Prompter)
- [Link - project plan](https://github.com/pmartin5-gif/HelloWorld/blob/main/Week-8/LightBoard_Prompter/projectPlan.md)
- [Link - documentation](https://github.com/pmartin5-gif/HelloWorld/blob/main/Week-8/LightBoard_Prompter/documentation.md)

While I’ve been walking through this process, I realized that this is going to take more time than I have in order to complete this by Monday. So I need to switch gears.

I realized that I had another candidate for a project I can iterate on.

## The Assignment – Image Borkilator

### Overview

I ran into an issue creating a presentation for PComp recently where I was trying to find good images for background slides and went through the usual process of using google image search. This doesn’t always work great, because if I find an image, maybe the resolution or the shape isn’t great, and then often there’s a watermark.

Then I went to free stock image sites and ran into similar issues.

So, I thought, maybe I could create my own platform to generate background images for slides for a presentation.

At first I found this pleasing black and white, dreamy ink images. But then I thought it might be neat to subvert these using a system to introduce glitches or distortions into the image.

I’m inspired very much by a conversation I had with a friend who was talking about the usefulness of AI. He used this metaphor of audio equipment developed in the 40s and 50s. Originally, it was meant to cleanly reproduce sound, but very quickly, people began deliberately “breaking” the equipment to produce distortion, weird synth effects, and other creative elements that were not the intended purpose of the creators. There is a company called [Metasonix](https://en.wikipedia.org/wiki/Metasonix) which has had a history of creating pedals or synthesizers that deliberately introduce things into a signal that screw it up. They have very questionable naming conventions, but the idea of introducing distortion is really interesting to me.

I also remember from Carrie’s class learning about how computers “see” or generate images, and there seemed like a lot of opportunity to introduce breakages into that process.

So I used AI to generate a platform where I could generate these dreamy black and white images and then run them through a pass where there were a number of options to “break” the image. It took a couple of iterations but I was pretty happy with the result, and it produced usable output for the slides I made.

I also have been experimenting with a workflow after the last HelloWorld class to have the agent keep documentation for each project.

I’ve saved this documentation in this folder: https://github.com/pmartin5-gif/HelloWorld/blob/main/Week-8/image%20borker/documentation.md

Find below a short video to illustrate where it currently stands.

https://github.com/pmartin5-gif/HelloWorld/blob/main/Week-8/image%20borker/borker%20starting%20place%20overview.mov

### The work

**My Goal:** Generally, I want to make this tool applicable to any image and I also want to make the distortion effects more interesting.

**The change:** I would like the option for the user to upload their own image and then apply distortion effects to that.

I would like to adjust the distortion effects to make them easier to understand, more interesting, and more significant.

To do this, I am going to supply the following prompts:

**Intention I:** Creating a backup of the current version.

**Prompt:** I would like to preserve a record of the current version. can you create a backup in a new folder called 'archive?'

**What I expect:** codex generates a backup of the current version in a new folder called ‘archive.’

**The result:** success

**Intention II**: deprecate the image generation workflow and instead allow a user to upload their own image.

**Prompt: [in /plan mode]**

Great. Now we're going to get into the work. First, I want to deprecate the entire workflow contained under the 'source' menu subsetting. Instead, present the user an option to upload their own image. That image will be allowed to be manipulated using the 'signal' settings. Please maintain all of the other components of the platform except the removal of the 'source' settings for now. Please raise any questions we should answer about workflow, error handling, or etc and we can work through them.

**What I Expect:** what i hope for is that codex will delete the ‘source’ menu and instead just present the user an option to upload an image. I suspect it’s going to be a lot more complicated than this and we’ll run into some questions around image handling and file types and etc, but I want those generally to be handled using best practices so I’m going to let the AI make those decisions for now.

**The results:**

Because it’s in planning mode, it raises the following questions:

*The main dependency is that Signal currently processes monochrome pixels. Supporting color uploads therefore requires a choice about color handling. Output dimensions and saved settings also live in the existing Source workflow, so those need explicit replacements.*

*I’ll preserve Signal, history and branching, Original/Current comparison, zoom, and PNG export. A failed upload should leave the current work intact. The archived version will remain untouched.*

![image.png](Week%208%20-%20Documentation/image.png)

**I chose to preserve color. I also chose to preserve the original size of the image. And there was a third option about how the manipulated images were saved and I didn’t really understand it so I went with the recommended choice.**

Here’s an example of something it flagged for me that I didn’t think of.

![image.png](Week%208%20-%20Documentation/image%201.png)

I chose ‘preserve transparency’ because that would be important for people doing work on logos sometimes.

The last question makes me worry a little about data handling, because i don’t want to come anywhere close to handling other people’s images. but i can come back to this later.

Here is the summary that /plan provided before executing:

```markdown
# Replace Source generation with image uploads

## Summary

Replace the procedural Source workflow with a compact Upload image control above Signal. Users begin with their own image, then apply the existing cumulative Signal passes.

Preserve color, transparency, native dimensions, history, branching, comparison, zoom, and PNG export. Keep the archived version unchanged.

## Workflow and interface

- Remove Source/Signal tabs and all procedural Source controls, including generation, materials, structures, seeds, and output-size settings. Keep Signal visible.
- Start with an empty workspace inviting upload. Disable image-dependent actions until an image loads successfully; allow Signal settings to be prepared.
- Accept one PNG, JPEG, or WebP still image through a file picker. Reject animated images and unsupported formats with a clear explanation.
- A successful upload starts an untouched study, retaining earlier studies in History and the current prepared Signal settings. Effects run only when Apply pass is pressed.
- Use the uploaded filename for the study title and a sanitized filename stem for downloads.
- Update Source-specific instructions and status text while preserving existing branding and layout.
- Show transparency over a checkerboard preview; exclude the checkerboard from exports.

## Image processing and saved work

- Decode uploads locally, honor image orientation, and process at native dimensions without enlargement or cropping.
- Retain the existing upper limits: 8192 pixels per side and 16,777,216 pixels total. Offer Resize proportionally or Cancel when exceeded, showing the proposed dimensions first. Allow dimensions down to one pixel for uploaded images.
- Extend the engine and worker to use RGBA pixels. Displacement, pull, and data slip move whole pixels together. Pixel sort orders whole pixels by brightness, keeping colors and transparency attached.
- Apply weave, tone crush, and shared noise to RGB channels; these tonal operations leave alpha unchanged. Pass mix blends color and alpha using premultiplied color, preserving existing overdrive behavior and clamping results.
- Preserve current effect order, ranges, presets, seeds, explicit passes, no-op handling, and the 64-pass limit. Opaque grayscale input should retain the current version-2 effect results.
- Introduce version-3 self-contained JSON saves containing dimensions, original filename, the normalized starting image embedded as PNG, and applied Signal passes. Store the starting asset once per study in memory.
- Open settings reconstructs the uploaded study and its history. Reject version-1/2 procedural saves with guidance to use the archived version.
- Preserve Original/Current comparison, exact history restoration, branching, session limits, and current-result export behavior.

## Errors and safeguards

- Cancellation leaves the workspace unchanged. Invalid, corrupted, animated, oversized, or undecodable files produce actionable messages.
- Use a 100 MiB upload-file limit and a 128 MiB saved-file limit; explain these limits when exceeded.
- Validate saved-image dimensions, embedded image data, and pass settings before replay.
- Prepare imports and settings replay before committing them to the workspace. Decode, processing, or encoding failures preserve the existing study and history.
- Prevent overlapping operations, allow the same file to be selected again, and release temporary image resources.
- Keep all processing local, with the existing worker and local-file fallback.

## Validation and documentation

- Test color and alpha preservation, every Signal effect, deterministic seeds, cumulative passes, no-op passes, grayscale compatibility, and worker/fallback agreement.
- Test upload cancellation and failures, proportional resizing, narrow images, repeated uploads, retained settings, history branching, Original comparison, and PNG export.
- Verify self-contained save/reopen reproduces the result without the original external file; test malformed saves and legacy-save rejection.
- Review responsive layout, keyboard access, transparency preview, native decoding, and actual downloads in a browser where available; report any verification limits.
- Update active documentation and project guidance to supersede procedural-generation requirements and record these decisions. Leave the archive untouched.

## Defaults

Uploads remain session-local unless explicitly saved or exported. No drawing tools, regional editing, additional effects, hosting, or visual rebranding are included.

```

**Result**

![image.png](Week%208%20-%20Documentation/image%202.png)

At face value this is ok. As I’m reviewing I will keep a list of the things I wish to change:

1. my first move was to click the ‘begin with your image’ section to upload an image but it didn’t do anything.
2. there are obviously a lot of extraneous little details here and the branding sucks but i will worry about that later

Other than that I think it actually works pretty well:

**Original:**

![image.png](Week%208%20-%20Documentation/image%203.png)

**Result:**

![afterimage-Screenshot-2026-11-04-at-6-33-57-PM-pass-04-754x526.png](Week%208%20-%20Documentation/afterimage-Screenshot-2026-11-04-at-6-33-57-PM-pass-04-754x526.png)

Here is a list of things I want to do next:

- Create the option to click the ‘begin with your image’ section to upload an image.
- Add a distortion setting called ‘cosmic particle’ which randomly changes one of the variable RGB settings for each pixel. Increasing this setting will increase the % of pixels changed.
- Provide a setting for users to quickly distort an image.
    - this will be a slider called ‘borkilation.’ increases the slider manipulates all of the sub sliders, which will still exist but maybe will be under an ‘advanced settings tab’ submenu.
- get rid of all extraneous features and copy. codex adds a lot of little buttons and doo-dads and flavor text and i need to go through and just delete all of these.
- change branding to ‘borkilator.’ this includes changes the ‘apply button’ to just say ‘borkilate.’